#ifndef _INTERFACE_RX_H
#define _INTERFACE_RX_H

BOOLEAN InterfaceRx(PS_INTERFACE_ADAPTER Adapter);

#endif

