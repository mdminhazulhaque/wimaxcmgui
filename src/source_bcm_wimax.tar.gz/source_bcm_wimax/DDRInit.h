#ifndef _DDR_INIT_H_
#define _DDR_INIT_H_



int ddr_init(PMINI_ADAPTER	psAdapter);
int download_ddr_settings(PMINI_ADAPTER	psAdapter);

#endif
