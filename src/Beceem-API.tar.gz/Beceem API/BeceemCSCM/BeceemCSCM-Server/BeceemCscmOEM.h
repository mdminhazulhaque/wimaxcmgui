/* ---------------------------------------------------- */
/*	Client-Server Connection Manager                    */
/*	Copyright 2010 Beceem Communications, Inc.          */
/*                                                      */
/*	December 2010                                           */
/* ---------------------------------------------------- */

BOOL BeceemCscmOEM_GetCAPLParams (ST_CAPL_BASED_SEARCH_PARAMS *lpsmParams);

