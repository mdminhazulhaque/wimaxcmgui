/* ---------------------------------------------------- */
/*	Client-Server Connection Manager                                  */
/*	Copyright 2008 Beceem Communications, Inc.          */
/*                                                      */
/*	Carlos Puig (cpuig@beceem.com)                      */
/*	July 2008                                           */
/* ---------------------------------------------------- */

#define CSCM_PACKAGE_VERSION     "1.1.7.0"
#define CSCM_FILE_VERSION     	 1,1,7,0

#define CLIENT_VERSION CSCM_PACKAGE_VERSION
#define SERVER_VERSION CSCM_PACKAGE_VERSION 

