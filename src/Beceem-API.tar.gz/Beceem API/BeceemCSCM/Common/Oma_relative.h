#ifndef OMA_RELATIVE_H
#define OMA_RELATIVE_H

int call_OMA_cli(int port, int type);
#endif