#include "BeceemWiMAX.h"
#include "WiMAXCommonAPI.h"

#include "DebugPrint.h"
#include "Typedefs.h"
#include "SyncObjects.h"

extern PBECEEM_COMMON_API_DEVICE_DATA pDeviceData;
extern PBECEEMWIMAX GpWiMAX;
extern DEBUGPRINT *GTraceDebug;
