

/* DLL_VERSION is a Library Version 
 Used for both WIN32 and non-WIN32 versioning.
*/ 
#define DLL_VERSION "06.00.37"

/*DLL_FILE_VERSION is a rc file version. 
It should be same as DLL_VERSION */
#define DLL_FILE_VERSION 0,6,0,37

/* PROJECT_NUMBER is the version of CHM document*/

//  PROJECT_NUMBER         = 06.00.37

